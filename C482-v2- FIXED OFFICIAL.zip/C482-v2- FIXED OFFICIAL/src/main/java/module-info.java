module c482.c482 {
    requires javafx.controls;
    requires javafx.fxml;


    opens c482.Main to javafx.fxml;
    exports c482.Main;
    exports c482.Controller;
    opens c482.Controller to javafx.fxml;
    exports c482.Model;
    opens c482.Model to javafx.fxml;
}